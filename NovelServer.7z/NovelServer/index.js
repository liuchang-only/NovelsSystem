var express = require('express');
var app = express();
var path = require('path');
var cors = require("cors"); //跨域插件
var bodyParser = require('body-parser');
var multer = require('multer');
var fs = require('fs');

var router = require('./routers');


//设置静态目录
app.use(express.static(path.join(__dirname, 'public')))
app.use(bodyParser.urlencoded({
	extended: true
}))


app.use(bodyParser.json())

//设置跨域
app.all('*', function(req, res, next) {
	res.header("Access-Control-Allow-Origin", "*");
	res.header("Access-Control-Allow-Headers", "Content-Type,Content-Length, Authorization, Accept,X-Requested-With");
	res.header("Access-Control-Allow-Methods", "PUT,POST,GET,DELETE,OPTIONS");
	res.header("Access-Control-Allow-Credentials", true);
	res.header("X-Powered-By", ' 3.2.1')
	if (req.method == "OPTIONS") res.send(200); /*让options请求快速返回*/
	else next();
});
//  // 把登陆和注册请求去掉了，其他的有请求都需要进行token校验
// app.use(function (req, res, next) {
//     
//     if (req.url != '/user/onload' && req.url != '/user/save') {
//         let token = req.headers.token;
//         let jwt = new JwtUtil(token);
//         let result = jwt.verifyToken();
//         // 如果考验通过就next，否则就返回登陆信息不正确
//         if (result == 'err') {
//             console.log(result);
//             res.send({code: 403,msg: '登录已过期,请重新登录'});
//             // res.render('login.html');
//         } else {
//             next();
//         }
//     } else {
//         next();
//     }
// });

router(app)

app.listen(88, function() {
	console.log("服务已启动··· ···")
})
/* 	//设置允许跨域  *代表所有域名
	res.header("Access-Control-Allow-Origin","*"); */
