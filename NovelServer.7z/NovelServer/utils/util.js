
//小于9的数前面添加0
function anum(num){
	return num<=9 ? '0'+num : num
}

function showTime(date){
	return date.getFullYear()+'-'+anum(date.getMonth()+1)+'-'+anum(date.getDate())+' '+anum(date.getHours())+':'+anum(date.getMinutes())+':'+anum(date.getSeconds());
}

module.exports = {
	anum:anum,
	showTime:showTime
}