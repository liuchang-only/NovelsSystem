 /**
 2  * 聚合查询 查询多条数据 多表查询
 3  * @param table_name 表名
 4  * @param pipeLine 管道 [{$lookup: {
 5                         from:'表名',            // 右集合
 6                         localField: 'UserId',    // 左集合 join 字段 数据类型得统一
 7                         foreignField: '_id',         // 右集合 join 字段 数据类型得统一
 8                         as: 'fromUser',           // 新生成字段（类型array）   
 9                     }}
10                     ,{$match:{"_id:''}},
11                      { $unwind: "$fromUser" },//数据打散
12                 ]
13  * @param callback 回调方法
14  */
15 MongoDbAction.queryAggregateMultiTable = function (table_name, pipeLine, callback) {
16     var node_model = this.getConnection(table_name);
17     if (!node_model || node_model.message) {
18         if (callback) callback(1, node_model)
19     } else {
20         node_model.aggregate(pipeLine)
21             .exec(function (err, res) {
22                 if (err) {
23                     if (callback) callback(err);
24                 } else {
25                     if (callback) callback(null, res);
26                 }
27             });
28     }
29 };

module.exports = {
	MongoDbAction.queryAggregateMultiTable:MongoDbAction.queryAggregateMultiTable,
}