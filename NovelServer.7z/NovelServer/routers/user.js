var express = require('express')
var router = express.Router()
var userModel = require('../models/users')
var bookshelfModel = require('../models/bookshelf')
var adminModel = require('../models/admin')
var multer = require('multer')
var jwt = require('jsonwebtoken'); //jwt token 工具
//管理员登录
router.post('/adminload', function(req, res) {
	console.log(req.body)
	var user = {
		uname: req.body.uname,
		pw: req.body.password
	}
	adminModel.find(user, function(err, admin) { //查找user表中的用户
		if (admin.length > 0) { //用户验证成功

			res.json({
				code: 1,
				msg: "login success",
			}) //登录成功
		} else {
			res.send({
				code: 0,
				msg: "用户名或密码错误"
			}) //用户名或密码错误
		}
	})
})
//用户注册事件
router.post('/save', function(req, res) {


	userModel.find({
		tel: req.body.tel
	}, function(err, msg) {
		if (err) {
			res.json({
				"code": -1,
				"data": err
			})
		} else {
			if (msg.length > 0) {
				res.json({
					"code": 0,
					"data": "用户已存在"
				}) //用户名已存在
			} else {

				var user = new userModel({
					tel: req.body.tel,
					pw: req.body.pw,

				})
				user.save(function(err, doc) {
					if (err) {
						res.json({
							"code": -1,
							"data": err
						}) //注册失败
					} else {
						res.json({
							"code": 1,
							"data": "reg success"
						})
						// //同时创建书架
						// new bookshelfModel({
						// 	uId: doc._id,
						// 	nIdArr: []
						// }).save()
					}

				}) //用户名可以使用

			}

		}
	})
})
//验证手机号是否已注册
router.get('/reg', function(req, res) {

	userModel.find({
		tel: req.query.tel
	}, function(err, msg) {
		if (err) {
			res.json({
				"code": -1,
				"data": err
			})
		} else {
			if (msg.length > 0) {
				res.json({
					"code": 0,
					"data": "该手机号已注册！"
				}) //用户名已存在
			} else {
				res.json({
					"code": 1,
					"data": "用户名可用！"
				}) //用户名可以使用
			}
		}
	})
})

// //登录
// router.get('/login', function(req, res) {

// 	userModel.find(function(err, msg) {
// 		if (err) {
// 			return res.json({
// 				code: -1,
// 				data: err
// 			})
// 		}
// 		res.json({
// 			code: 1,
// 			data: msg
// 		})
// 	})
// })

//登录事件处理
router.post('/onload', function(req, res) {
	// console.log(req.body)
	var user = {
		tel: req.body.tel,
		pw: req.body.pw
	}
	userModel.find(user, function(err, users) { //查找user表中的用户
		if (users.length > 0) { //用户验证成功
			//生成tokenid
			// var token = jwt.sign(Object.assign({}, users._id), 'keven', { //一个对象，用于储存用户信息的   'keven':加密字段，可以自己随便定义   expiresIn：过期时间单位是秒
			// 	expiresIn: 180 //3分钟过期
			// });
			// console.log(users)
			res.json({
				code: 1,
				data: {
					_id: users[0]._id,
					user: users[0].tel
				},
				// msg: users
				// user: users[0]._id,
				// token: token
			}) //登录成功
		} else {
			res.send({
				code: 0,
				data: "用户名或密码错误"
			}) //用户名或密码错误
		}
	})
})

//找回密码
router.post('/forgot', function(req, res) {
	// console.log(req.body)


	userModel.findj({
		tel: req.body.tel
	}, function(err, msg) {
		if (err) {
			res.send('false') //获取失败
		} else {
			if (msg.length > 0) {
				res.send(msg[0].pw)
			} else {
				res.send('no')
			}

		}
	})
})
//修改密码
router.post('/updatepw', function(req, res) {
	console.log(req.body)
	userModel.find({
		_id: ObjectId(req.body.uId)
	}, function(err, msg) {
		if (req.body.oldpw == msg[0].pw) {
			userModel.update({
				pw: msg[0].pw
			}, {
				$set: {
					pw: req.body.pw
				}
			}, function(err) {
				if (err) {
					res.send(err)
				} else {
					res.send('success')
				}
			})
		} else {
			res.send('pwerr')
		}
	})
})
//修改用户信息
router.post('/updateper', function(req, res) {
	console.log(req.body)
	userModel.updateOne({
		_id: ObjectId(req.body._id)
	}, req.body, function() {})
	res.send('ok')
})
//获取用户信息
router.get('/user', function(req, res) {

	userModel.find({
		_id: ObjectId(req.query.userid)
	}, function(err, msg) {
		if (err) {
			res.send('false') //获取失败
		} else {
			res.send({
				msg
			})
		}
	})
})


//查找用户书架
router.get("/bookshelf", function(req, res) {
	console.log(req.query.uId)
	bookshelfModel.find({
		uId: req.query.uId
	}).populate({
		path: 'nIdArr',
		model: 'novels'
	}).exec(function(err, docs) {
		if (err) {
			res.json({
				code: -1,
				data: err
			})
		} else {
			res.json({
				code: 1,
				data: docs[0]
			})
		}
	})
})

router.post('/delbook', function(req, res) {
	bookshelfModel.update({
		uId: req.body.uId
	}, {
		$pull: {
			'nIdArr': req.body._id
		}
	}, function(err, docs) {
		if (err) {
			res.json({
				code: -1
			})
		} else {
			res.json({
				code: 1
			})
		}

	})
})

module.exports = router;
