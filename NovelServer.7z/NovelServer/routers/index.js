var user = require('./user')
// var login = require('./login')
var bg = require('./bg')
var fg = require('./fg')
var userModel = require('../models/users')


module.exports = function(app) {
// 	app.get('/', function(req, res) {
// 
// 		if (req.session.user == undefined) {
// 			res.locals.user = ''
// 		} else {
// 			res.locals.user = req.session.user
// 		}
// 
// 	})
// 	app.get('/exit', function(req, res) {
// 
// 		req.session.user = ''
// 		res.redirect('/')
// 	})

	app.use('/user', user)
	app.use('/bg',bg)
	app.use('/fg',fg)
}
