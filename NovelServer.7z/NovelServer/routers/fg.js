var express = require('express')
var router = express.Router()
var userModel = require('../models/users')
var novelModel = require('../models/novels')
var bookshelfModel = require('../models/bookshelf.js')
var rankingModel = require('../models/rankings')
var msgModel = require('../models/msgs')
var ObjectId = require('mongodb').ObjectID
var util = require('../utils/util')
// var orderModel = require('../models/orders')
// var refundModel = require('../models/refund')



/*根据ID查找详情*/
router.get('/findnovel', (req, res) => {
	novelModel.findOne({
		_id: ObjectId(req.query.nId)
	}, function(err, docs) {
		if (err) {
			res.json({
				code: -1,
				data: err
			})
		} else {
			res.json({
				code: 1,
				data: docs
			})
		}
	})

})

//根据类型分类小说
router.get('/detail', (req, res, next) => {
	var nType = req.query.nType;
	if (nType == 0 || nType == '') {
		params = {};
	} else {
		params = {
			"nType": nType,
		}
	}

	novelModel.find(params, function(err, doc) {
		if (err) {
			res.json({
				code: '-1',
				data: err
			})
		} else {
			// console.log(doc)
			res.json({
				code: '1',
				data: doc

			})

		}
	})
})


//根据热门/收藏/推荐/点击排榜排序
router.get('/ranking', (req, res, next) => {

	var rType = req.query.rType;
	var sort
	switch (rType) {
		case "HotSearch":
			sort = {
				"rHotSearch": '-1'
			}
			break;
		case "Click":
			sort = {
				"rClick": '-1'
			}
			break;
		case "Recommend":
			sort = {
				"rRecommend": '-1'
			}
			break;
		case "Collection":
			sort = {
				"rCollection": '-1'
			}
			break;

		default:
			//新书榜
			sort = {
				"nId": '-1'
			}
			break;
	}
	rankingModel.find().populate('nId').sort(sort).exec(function(err, docs) {
		if (err) {
			return res.json({
				code: '-1',
				data: err
			})
		}
		res.json({
			code: '1',
			data: docs
		})
	})
	// .findOne({_id : studentId}).populate('clazzID').exec(callback)
})


//分类列表下的收藏排行榜
router.get('/detail/soucang', (req, res) => {
	var nType = req.query.nType
	console.log(nType)
	rankingModel.find().populate({
		path: 'nId',
		match: {
			"nType": nType
		}
		// select: '_id nImg nName author nType nCaution nIntro'
	}).sort({
		"rCollection": '-1'
	}).exec(function(err, docs) {
		if (err) {
			return next(err)
		}
		res.json({
			code: '1',
			data: docs.filter(function(doc) {
				return doc.nId != null
			})
		})
	})
	// .findOne({_id : studentId}).populate('clazzID').exec(callback)
})


//点击榜+1
router.post('/click', (req, res) => {
	// console.log(req.body)
	// res.send('ok')
	rankingModel.updateOne({
		"nId": req.body._id
	}, {
		$inc: {
			"rClick": 1
		}
	}, {
		upsert: true
	}, function(err, docs) {
		// console.log(docs)
		res.json({
			code: 1
		})
	})

})
//收藏榜+1
router.post('/collection', (req, res) => {

	//榜单加1
	rankingModel.updateOne({
		"nId": req.body._id
	}, {
		$inc: {
			"rCollection": 1
		}
	}, {
		upsert: true
	}, function(err, docs) {
		// console.log(docs)
		res.json({
			code: 1
		})
		//用户存书架
		bookshelfModel.update({
			'uId': req.body.uId
		}, {
			$addToSet: {
				'nIdArr': req.body._id
			}
		}, {
			upsert: true
		}, function(err, docs) {
			if (err) {
				console.log(186, err)
			}
		})

	})
})
//推荐榜+1
router.post('/recommend', (req, res) => {
	// console.log(req.body)
	// res.send('ok')
	rankingModel.updateOne({
		"nId": req.body._id
	}, {
		$inc: {
			"rRecommend": 1
		}
	}, {
		upsert: true
	}, function(err, docs) {
		// console.log(docs)
		res.json({
			code: 1
		})
	})

})
//搜索榜+1
router.post('/search', (req, res) => {
	// console.log(req.body)
	// res.send('ok')
	novelModel.find({
		'nName': req.body.nName
	}, function(err, docs1) {
		if (err) {
			res.json({
				code: -1
			})
		} else {

			rankingModel.updateOne({
				"nId": docs1[0]._id
			}, {
				$inc: {
					"rHotSearch": 1
				}
			}, {
				upsert: true
			}, function(err, docs) {
				console.log(docs1)
				if (err) {
					res.json({
						code: -1
					})
				} else {
					res.json({
						code: 1
					})
				}

			})
		}
	})


})
//搜索所有的小说
router.get('/findnovels', function(req, res) {
	novelModel.find({}, function(err, docs) {
		if (err) {
			res.json({
				code: -1,
				data: err
			})
		} else {
			res.json({
				code: 1,
				data: docs
			})
		}
	})
})

//加载小说评论
router.get("/getcomments", function(req, res) {
	// nId: mongoose.Schema.ObjectId,//小说对象 mongoose.Schema.ObjectId
	// uId: mongoose.Schema.ObjectId,//当前用户
	// mCreateTime: String,//留言发表时间
	// mContent:String//留言内容
	msgModel.find({
		'nId': req.query.nId
	}).populate({
		path: 'uId',
		select: 'tel'
	}).sort({
		"mCreateTime": -1
	}).exec(function(err, docs) {
		if (err) {
			res.json({
				code: -1,
				data: err
			})
		} else {
			res.json({
				code: 1,
				data: docs
			})
		}
	})
})
//发表小说评论
router.post("/publishcomment", function(req, res) {
	console.log(req.body)
	var comment = new msgModel({
		nId: req.body.nId, //小说对象 mongoose.Schema.ObjectId
		uId: req.body.uId, //当前用户
		mCreateTime: new Date().getTime(), //留言发表时间
		mContent: req.body.comment //留言内容
	})
	comment.save(function(err, docs) {
		if (err) {
			res.json({
				code: -1,
				data: err
			})
		} else {
			res.json({
				code: 1,
				data: docs
			})
		}
	})
})

//删除评论
router.post("/delcomment", function(req, res) {
	msgModel.remove({
		_id: ObjectId(req.body._id)
	}, function(err, doc) {
		if (err) {
			res.json({
				code: -1,
				data: err
			})
		} else {
			res.json({
				code: 1,
				data: doc
			})
		}
	})
})



module.exports = router
