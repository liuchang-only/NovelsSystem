var express = require('express')
var router = express.Router()
var fs = require("fs")
var userModel = require('../models/users')
var adminModel = require('../models/admin')
var novelModel = require('../models/novels')
var rankingModel = require('../models/rankings')
var msgModel = require('../models/msgs')
// var orderModel = require('../models/orders')
// var refundModel = require('../models/refund')

// .findOne({_id : studentId}).populate('clazzID').exec(callback)

var ObjectId = require('mongodb').ObjectID
var multer = require('multer')
//文件上传
var storage = multer.diskStorage({
	destination: function(req, res, cb) {
		cb(null, 'public/npic')
	},
	filename: function(req, file, cb) {
		// var arr = file.originalname.split('.');
		// var houzhui = arr[arr.length - 1];
		// cb(null, Date.now() + '.' + houzhui)
		cb(null, Date.now() + file.originalname)
	},
	// fileFilter: function fileFilter(req, file, cb) {
	// 	if (file.mimetype.substring(0, 'image'.length) == 'image') {
	// 		cb(null, true); // 接受这个文件
	// 	} else {
	// 		cb(null, false); // 拒绝这个文件
	// 	}
	// }
})

var upload = multer({
	storage: storage
})

//后台登陆
router.post('/onload', function(req, res) {
	console.log(req.body)
	adminModel.findOne({
		'name': req.body.name,
		'pw': req.body.pw
	}, function(err, msg) {
		if (err) {
			res.send(err)
		} else {
			if (msg != null) {
				res.send('succese')
			} else {
				res.send('err')
			}

		}
	})

})
//小说上传事件
//删除多余的图片
function delPic() {
	//删除除以保存图片以外的图片
	var arr1 = []; //当前所有图片
	var arr2 = []; //数据库中已存的图片
	fs.readdir('public/npic', function(error, data) {
		if (error) {
			console.log(error);
			return false;
		}

		// console.log(data); //data是数组类型，包含文件夹以及文件的名字(只有第一级目录内容)。拿到一个文件夹下面的所有目录  	
		arr1 = data
		novelModel.find(function(err, msg) {
			for (let i of msg) {
				arr2.push(i.nImg)
			}
			// console.log(arr2)
			for (let i of arr1) {
				console.log(i)
				if (arr2.indexOf(i) == -1) {
					fs.unlink('public/npic/' + i, function(error) {
						if (error) {
							console.log(error);
							return false;
						}
						console.log('删除文件成功');
					})
				}
			}
		})

	})
}
router.post('/novelsave', upload.single('file'), function(req, res) {
	// console.log(req.body)
	// console.log(req.file)

	var novel = new novelModel({
		nImg: req.file.filename, //封面图片
		nName: req.body.novelName, //小说书名
		author: req.body.author, //作者
		nType: req.body.type, //分类
		nCaution: req.body.caution,
		nIntro: req.body.intro //简介
		// mname: req.body.mname,
		// npic: req.file.filename,
	})
	novelModel.find({
		nName: req.body.novelName
	}, function(err, msg) {
		if (err) {
			res.json({
				"code": -1,
				"data": err
			})
		} else {
			if (msg.length > 0) {
				res.json({
					"code": 0,
					"data": '小说同名'
				}) //小说名已存在
				delPic()
			} else {
				novel.save(function(err, doc) {
					if (err) {
						res.json({
							"code": -1,
							"data": err
						}) //失败
					} else {
						res.json({
							"code": 1,
							"data": 'save success'
						})

					}
					// console.log(doc._id)
					//同时添加附属表--排行榜
					// let ranking = new rankingModel({
					// 	nId: doc._id, //小说对象 mongoose.Schema.ObjectId
					// 	rHotSearch: 0, //搜索次数,热搜榜
					// 	rClick: 0, //点击榜
					// 	rRecommend: 0, //推荐榜
					// 	rCollection: 0, //收藏榜
					// })
					// ranking.save()
					delPic()
				}) //用户名可以使用


			}
		}
	})
})
//小说删除
router.post('/delnovel', function(req, res) {
	// console.log(req.body)
	// res.send('ok')
	novelModel.findByIdAndRemove(req.body._id, function(err) {
		if (err) {
			res.json({
				"code": -1,
				"data": err
			})
		} else {
			res.json({
				"code": 1,
				"data": "delete success"
			})

			//同时删除ranking排行榜
			rankingModel.remove({
				"nId": req.body._id,
				function(err) {
					console.log(err)
				}
			})
		}
	})
	delPic()
})
//小说修改
//无图
router.post('/updatenovel0', function(req, res) {
	// console.log(req.body)
	// console.log(req.file)
	novelModel.findByIdAndUpdate(req.body._id, req.body, function(err) {
		if (err) {
			return res.json({
				"code": -1,
				"data": err
			})
		} else {

			res.json({
				"code": 1,
				"data": "update success"
			})
		}
	})

})
//有图
router.post('/updatenovel1', upload.single('file'), function(req, res) {
	// console.log(req.body)
	// console.log(req.file)
	var updatedata = {
		nImg: req.file.filename, //封面图片
		nName: req.body.nName, //小说书名
		author: req.body.author, //作者
		nType: req.body.nType, //分类
		nCaution: req.body.nCaution,
		nIntro: req.body.nIntro //简介
	}
	novelModel.findByIdAndUpdate(req.body._id, updatedata, function(err) {
		if (err) {
			return res.json({
				"code": -1,
				"data": err
			})
		} else {
			res.json({
				"code": 1,
				"data": "update success"
			})
		}
		delPic()
	})

})



//小说列表
router.get('/nlist', function(req, res) {
	novelModel.find(function(err, msg) {
		if (err) {
			res.json({
				"code": -1,
				"data": err
			}) //注册失败
		} else {
			res.json({
				"code": 1,
				"data": msg
			})
		}
	})
})

//添加小说章节
router.post('/addContent', function(req, res) {
	// console.log(req.body)
	novelModel.update({
		_id: ObjectId(req.body._id),
		'nContents.No': {
			$ne: req.body.No
		}
	}, {
		$push: {
			nContents: { //章节内容
				No: req.body.No,
				contentName: req.body.contentName,
				updateTime: new Date().getTime(),
				content: ''
			}
		}
	}, function(err, docs) {
		if (err) {
			res.json({
				code: -1,
				data: err
			})
		} else {
			res.json({
				code: 1,
				data: docs
			})
		}
	})
})

//添加或这修改小说章节
router.post('/updateContent', function(req, res) {
	// console.log(req.body)
	novelModel.updateOne({
		_id: ObjectId(req.body.nId),
		"nContents._id": req.body._id
	}, {
		$set: {
			// "nContents.$": { //章节内容
			// 	_id: req.body._id,
			// 	No: req.body.No,
			// 	contentName: req.body.contentName,
			// 	updateTime: new Date().getTime(),
			// 	content: req.body.content
			// }
			"nContents.$.No": req.body.No,
			"nContents.$.contentName": req.body.contentName,
			"nContents.$.updateTime": new Date().getTime(),
			"nContents.$.content": req.body.content
		}
	}, function(err, docs) {
		if (err) {
			res.json({
				code: -1,
				data: err
			})
		} else {
			res.json({
				code: 1,
				data: docs
			})
		}
	})
})
//删除章节
router.post('/delContent', function(req, res) {
	// console.log(req.body)
	novelModel.update({
		_id: ObjectId(req.body.nId),
	}, {
		$pull: {
			"nContents": {
				_id: ObjectId(req.body._id)
			}
		}
	}, function(err, docs) {
		if (err) {
			res.json({
				code: -1,
				data: err
			})
			console.log(err)
		} else {
			res.json({
				code: 1,
				data: docs
			})
		}
	})
})


module.exports = router;
