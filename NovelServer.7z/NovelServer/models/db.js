var mongoose = require('mongoose')
mongoose.set('useFindAndModify', false)

mongoose.connect('mongodb://localhost/NS',{useNewUrlParser:true})  //连接本地数据库

var db = mongoose.connection;	//connect() 返回一个待定的连接， 
db.on('error',console.error.bind(console,'connection error:'))	//加载失败，打印connection error
db.once('open',function(){	
	console.log('open')	//加载成功打印open
})


module.exports = mongoose