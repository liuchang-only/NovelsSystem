var mongoose = require('./db')

var adminSchema = mongoose.Schema({	//指定数据的类型
	name: String,
	pw:String,

},{collection:'admin'})	//指定数据库

var adminModel = mongoose.model('admin',adminSchema);	//定义一个model，数据添加到adminSchema，数据类型引用adminSchema指定的
adminModel.find(function(err,admins){
	console.log("admin表连接成功")
})


module.exports = adminModel