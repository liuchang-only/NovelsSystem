var mongoose = require('./db')

var userSchema = mongoose.Schema({ //指定数据的类型
	tel: String,
	pw: String,
	
}, {
	collection: 'users'
}) //指定数据库

var userModel = mongoose.model('users', userSchema); //定义一个model，数据添加到userSchema，数据类型引用userSchema指定的
userModel.find(function(err, users) {
	console.log("users表连接成功")
})

module.exports = userModel
