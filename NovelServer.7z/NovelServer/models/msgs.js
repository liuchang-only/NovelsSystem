var mongoose = require('./db')

var msgSchema = mongoose.Schema({ //指定数据的类型
	nId: {
		type: mongoose.Schema.ObjectId,
		ref: 'novels'
	}, //小说对象 mongoose.Schema.ObjectId
	uId: {
		type: mongoose.Schema.ObjectId,
		ref: 'users'
	}, //当前用户
	mCreateTime: String, //留言发表时间
	mContent: String //留言内容
}, {
	collection: 'msgs'
}) //指定数据库

var msgModel = mongoose.model('msgs', msgSchema); //定义一个model，数据添加到msgchema，数据类型引用msgchema指定的
msgModel.find(function(err, msg) {
	console.log("msg表连接成功")
})


module.exports = msgModel
