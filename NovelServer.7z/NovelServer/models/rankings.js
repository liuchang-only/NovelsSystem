var mongoose = require('./db')

var rankingSchema = mongoose.Schema({ //指定数据的类型
	nId: {
		type: mongoose.Schema.ObjectId,
		ref: 'novels'
	}, //小说对象 mongoose.Schema.ObjectId
	rHotSearch: Number, //搜索次数,热搜榜
	rClick: Number, //点击榜
	rRecommend: Number, //推荐榜
	rCollection: Number, //收藏榜

}, {
	collection: 'rankings'
}) //指定数据库

var rankingModel = mongoose.model('rankings', rankingSchema); //定义一个model，数据添加到rankingSchema，数据类型引用rankingSchema指定的
rankingModel.find(function(err, rankings) {
	console.log("rankings表连接成功")
})


module.exports = rankingModel
