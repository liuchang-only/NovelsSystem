var mongoose = require('./db')

var bookshelfSchema = mongoose.Schema({ //指定数据的类型
	uId: {
		type: mongoose.Schema.ObjectId,
		ref: 'users'
	},
	nIdArr: Array, //小说id集合

}, {
	collection: 'bookshelf'
}) //指定数据库

var bookshelfModel = mongoose.model('bookshelf', bookshelfSchema); //定义一个model，数据添加到bookshelfSchema，数据类型引用bookshelfSchema指定的
bookshelfModel.find(function(err, bookshelf) {
	console.log("bookshelf表连接成功")
})

module.exports = bookshelfModel
