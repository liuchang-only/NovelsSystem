var mongoose = require('./db')

var novelSchema = mongoose.Schema({ //指定数据的类型

	nImg: String, //封面图片
	nName: String, //小说书名
	author: String, //作者
	nType: String, //分类
	nCaution: String, //小说金句
	nIntro: String, //简介
	nContents: [{//章节内容
		No:Number,
		contentName:String,
		updateTime:String,
		content:String
	}]


}, {
	collection: 'novels'
}) //指定数据库

var novelModel = mongoose.model('novels', novelSchema); //定义一个model，数据添加到novelSchema，数据类型引用novelSchema指定的
novelModel.find(function(err, novels) {
	console.log("novels表连接成功")
})


module.exports = novelModel
